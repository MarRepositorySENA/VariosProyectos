package com.AMONIC.Airlines;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AirlinesApplicationTests {

	@Test
	void contextLoads() {
	}

}
