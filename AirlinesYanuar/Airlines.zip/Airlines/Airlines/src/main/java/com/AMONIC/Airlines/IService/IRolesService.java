package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Roles;

public interface IRolesService extends IBaseService<Roles>{

}
