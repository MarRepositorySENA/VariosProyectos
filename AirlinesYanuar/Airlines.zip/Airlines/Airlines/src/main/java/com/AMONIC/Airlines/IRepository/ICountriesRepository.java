package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.Countries;

public interface ICountriesRepository extends IBaseRepository<Countries, Long>{

}
