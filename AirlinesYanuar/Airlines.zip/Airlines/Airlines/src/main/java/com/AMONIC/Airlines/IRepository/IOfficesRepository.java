package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.Offices;

public interface IOfficesRepository  extends IBaseRepository<Offices,Long>{

}
