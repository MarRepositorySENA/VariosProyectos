package com.AMONIC.Airlines.IRepository;


import com.AMONIC.Airlines.Entity.Roles;

public interface IRolesRepository extends IBaseRepository<Roles, Long> {

}
