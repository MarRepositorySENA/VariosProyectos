package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.CabinTypes;

public interface ICabinTypesRepository  extends IBaseRepository<CabinTypes, Long>{

}
