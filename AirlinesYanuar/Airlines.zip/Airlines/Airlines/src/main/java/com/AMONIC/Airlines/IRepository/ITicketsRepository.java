package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.Tickets;

public interface ITicketsRepository extends IBaseRepository<Tickets, Long>{

}
