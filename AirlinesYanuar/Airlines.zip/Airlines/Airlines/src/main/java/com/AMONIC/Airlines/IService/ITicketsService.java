package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Tickets;

public interface ITicketsService extends IBaseService<Tickets>{

}
