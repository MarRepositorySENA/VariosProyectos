package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Routes;

public interface IRoutesService extends IBaseService<Routes>{

}
