package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.CabinTypes;

public interface ICabinTypesService extends IBaseService<CabinTypes>{

}
