package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Airports;

public interface IAirportsService extends IBaseService<Airports>{

}
