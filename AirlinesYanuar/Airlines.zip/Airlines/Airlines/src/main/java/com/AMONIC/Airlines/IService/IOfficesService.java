package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Offices;

public interface IOfficesService extends IBaseService<Offices>{

}
