package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Aircrafts;

public interface IAircraftsService extends IBaseService<Aircrafts>{

}
