package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.Users;

public interface IUsersRepository extends IBaseRepository<Users, Long> {

}
