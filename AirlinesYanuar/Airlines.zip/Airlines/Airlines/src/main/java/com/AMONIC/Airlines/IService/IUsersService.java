package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Users;

public interface IUsersService extends IBaseService<Users>{

}
