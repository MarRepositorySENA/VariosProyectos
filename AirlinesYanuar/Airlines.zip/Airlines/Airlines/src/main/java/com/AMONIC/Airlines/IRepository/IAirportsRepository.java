package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.Airports;

public interface IAirportsRepository extends IBaseRepository<Airports , Long>{

}
