package com.AMONIC.Airlines.IService;

import com.AMONIC.Airlines.Entity.Countries;

public interface ICountriesService extends IBaseService<Countries> {

}
