package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.Routes;

public interface IRoutesRepository extends IBaseRepository<Routes, Long>{

}
