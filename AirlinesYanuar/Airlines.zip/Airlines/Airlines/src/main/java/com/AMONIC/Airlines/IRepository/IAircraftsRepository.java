package com.AMONIC.Airlines.IRepository;

import com.AMONIC.Airlines.Entity.Aircrafts;

public interface IAircraftsRepository extends IBaseRepository<Aircrafts, Long>{

}
