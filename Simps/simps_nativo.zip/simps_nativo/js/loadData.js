function loadModules(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/seguridad/modules',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione Un Módulo--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.description+`</option>
                        `;
        })
        $("#moduleId").html(registros);   
    })
}
function loadViews(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/seguridad/views',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione Una Vista--</option>`;
        items.forEach(function (item, index, array) {
            registros += `<option value="${item.id}" data-view-id="${item.id}">${item.label}</option>`;
        })
        $("#viewId").html(registros);   
    })
}
function loadRoles(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/seguridad/roles',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione Un Rol--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.description+`</option>
                        `;
        })
        $("#roleId").html(registros);   
    })
}
function loadPersons(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/seguridad/persons',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione Una Persona--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.firstName+`</option>
                        `;
        })
        $("#personId").html(registros);   
    })
}

function loadBrand(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/inventario/brands',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione una marca--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.name+`</option>
                        `;
        })
        $("#brandId").html(registros);   
    })
}

function loadTypesElements(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/inventario/typesElements',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione uun tipo elemento--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.name+`</option>
                        `;
        })
        $("#typesElements").html(registros);   
    })
}

function loadElement(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/inventario/elements',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione un elemento--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.name+`</option>
                        `;
        })
        $("#elementId").html(registros);   
    })
}

function loadClassroom(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/parametrizacion/classrooms',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione un salon--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.name+`</option>
                        `;
        })
        $("#classroomId").html(registros);   
    })
}

function loadPerson(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/seguridad/persons',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione una persona--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.firstName+`</option>
                        `;
        })
        $("#personId").html(registros);   
    })
}


function loadRole(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/seguridad/roles',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione un rol--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.description+`</option>
                        `;
        })
        $("#roleId").html(registros);   
    })
}


function loadModule(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/seguridad/modules',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione un modulo--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.description+`</option>
                        `;
        })
        $("#moduleId").html(registros);   
    })
}


function loadHeadquater(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/parametrizacion/headquaters',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione una sede--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.name+`</option>
                        `;
        })
        $("#headquaterId").html(registros);   
    })
}



function loadFloors(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/parametrizacion/floors',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione una sede--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.floorNumber+`</option>
                        `;
        })
        $("#floorId").html(registros);   
    })
}


function loadInstitute(){
    $.ajax({
        url: 'http://localhost:9000/simps/api/parametrizacion/institutes',
        method: "GET",
        headers: {
            "Content-Type": "application/json"
        }
    }).done(function (items) {
        var registros = `<option selected="" selected disabled hidden value="">--Seleccione una sede--</option>`;
        items.forEach(function (item, index, array) {
            registros += `                       
                            <option value="`+item.id+`">`+item.name+`</option>
                        `;
        })
        $("#instituteId").html(registros);   
    })
}




