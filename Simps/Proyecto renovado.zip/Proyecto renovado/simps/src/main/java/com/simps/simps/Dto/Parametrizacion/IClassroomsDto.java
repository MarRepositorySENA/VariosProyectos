package com.simps.simps.Dto.Parametrizacion;

public interface IClassroomsDto {
	
	Long getId();

	String getName();

	Integer getFloorId();
	
    Boolean getState();
	
	Long getQuantity();
}
