package com.simps.simps.IService.Inventario;

import com.simps.simps.Entity.Inventario.AmountsElements;
import com.simps.simps.IService.ObjectT.IBasicMethodsService;

public interface IAmountsElementsService extends IBasicMethodsService<AmountsElements>{

}
