package com.simps.simps.Dto.Parametrizacion;

public interface ICursesTeachersDto {

	Long getCurseId();

	Long getTeacherId();
	
}
