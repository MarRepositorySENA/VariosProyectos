package com.simps.simps.Dto.Parametrizacion;

public interface ISubjectsDto {

	Long getId();
	
	String getCode(); 

	String getName();

	String getTeacherId();
	
    Boolean getState();
	
	Long getQuantity();
	
}
