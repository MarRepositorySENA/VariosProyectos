package com.simps.simps.Dto.Inventario;

public interface IMotionClassroomAmountDto {

	String getClassroomName();
	
	Long getElementClassroomId();
	
	Long getElementId();
	
	String getElementName();
	
	Long getClassroomId();

	Integer getAmountQuantity();
	
	
	
	
}
