package com.simps.simps.Dto.Parametrizacion;

public interface IHeadquatersDto {
	
	Long getId();

	String getAddress();

	String getPhoneNumber();

	String getMail();

	String getNit();

	Long getInstituteId();
	
    Boolean getState();
	
	Long getQuantity();
	
	String getName();
	
}
