package com.simps.simps.Dto.Justifications;

public interface ISubjectsIdDto {

	Long getId();
	
	String getName();
	
}
