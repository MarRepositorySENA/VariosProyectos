package com.simps.simps.Dto.Parametrizacion;

public interface ICursesDto {
	
	Long getId();

	String getName(); 

	String getGradeId();
	
	String getClassroomId();

	String getTechniqueId();
	
    Boolean getState();
	
	Long getQuantity();
	
}
