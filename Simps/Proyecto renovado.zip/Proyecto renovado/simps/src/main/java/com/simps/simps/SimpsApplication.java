package com.simps.simps;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimpsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimpsApplication.class, args);
	}

}
