package com.simps.simps.Dto.Parametrizacion;

public interface IFloorsDto {
	
	Long getId();

	Integer getFloorNumber();
	
	String getHeadquaterId();

    Boolean getState();
	
	Long getQuantity();
	
}
