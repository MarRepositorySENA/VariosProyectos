package com.simps.simps.Dto.Seguridad;

public interface IPerfilUserDto {

	String getUserName();
	
	String getImage();
	
	String getRolDescription();
	
	String getFirstName();
	
	String getFirstLastName();
	
	Long getPersonId();
	
	
}
