package com.simps.simps.Dto.Parametrizacion;


public interface IStudentsDto {
	
	Long getId();

	String getEnrollmentDate();

	String getUserId();
	
    Boolean getState();
    
    String getCurseId();
	
	Long getQuantity();
	
}
