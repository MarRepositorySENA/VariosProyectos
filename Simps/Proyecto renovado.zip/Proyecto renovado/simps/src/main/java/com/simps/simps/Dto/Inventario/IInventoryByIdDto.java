package com.simps.simps.Dto.Inventario;

public interface IInventoryByIdDto {

	
	Integer getElementClassroomId();
	
	Integer getElementId();
	
	String getImage();
	
	String getName();
	
	String getDescription();
	
	String getBrand();
	

}
