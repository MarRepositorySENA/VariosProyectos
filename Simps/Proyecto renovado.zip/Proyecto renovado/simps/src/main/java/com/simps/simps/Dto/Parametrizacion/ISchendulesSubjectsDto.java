package com.simps.simps.Dto.Parametrizacion;

public interface ISchendulesSubjectsDto {
	
	Long getId();

	String getSubjectId();

	String getStartTime();
	
	String getEndTime();

	String getCurseId();
	
    Boolean getState();
	
	Long getQuantity();
}
