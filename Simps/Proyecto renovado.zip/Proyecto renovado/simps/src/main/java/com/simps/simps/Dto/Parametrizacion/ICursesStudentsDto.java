package com.simps.simps.Dto.Parametrizacion;

public interface ICursesStudentsDto {

	Long getCurseId();

	Long getStudentId();
	
}
