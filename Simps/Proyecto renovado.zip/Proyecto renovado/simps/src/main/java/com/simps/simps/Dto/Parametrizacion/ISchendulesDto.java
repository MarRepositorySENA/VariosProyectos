package com.simps.simps.Dto.Parametrizacion;



public interface ISchendulesDto {
	
	Long getId();

	String getStartTime();

	String getEndTime();
	
    Boolean getState();
	
	Long getQuantity();
	
	String getDay();
	
}
