package com.simps.simps.Dto.Asistencia;

public interface IFilterStudentsDto {

	String getPersonName();
	
	Long getPersonId();
}
