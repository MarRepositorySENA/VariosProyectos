package com.simps.simps.Dto.Parametrizacion;

public interface IInstitutesDto {

	Long getId();
	
	String getName(); 
	
	String getAddress();
	
	String getPhoneNumber();
	
	String getMail();
	
	String getNit();
	
    Boolean getState();
	
	Long getQuantity();
	
}
