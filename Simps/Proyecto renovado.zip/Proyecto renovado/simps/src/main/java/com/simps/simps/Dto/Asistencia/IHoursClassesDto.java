package com.simps.simps.Dto.Asistencia;

import java.time.LocalTime;

public interface IHoursClassesDto {

	LocalTime getStartTime();
	
	LocalTime getEndTime();
}
