package com.simps.simps.Dto.Parametrizacion;

public interface IGradesDto {
	
	Long getId();
	
	String getName();
	
    Boolean getState();
	
	Long getQuantity();
	
}
