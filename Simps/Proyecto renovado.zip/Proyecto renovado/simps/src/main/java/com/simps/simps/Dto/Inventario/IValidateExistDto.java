package com.simps.simps.Dto.Inventario;

public interface IValidateExistDto {

	Long getQuantity();
	
	Long getElementId();
	
}
