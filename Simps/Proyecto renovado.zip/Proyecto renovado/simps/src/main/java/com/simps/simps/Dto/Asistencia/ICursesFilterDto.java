package com.simps.simps.Dto.Asistencia;

public interface ICursesFilterDto {

	Long getCurseId();
	
	String getCurseName();
	
}
