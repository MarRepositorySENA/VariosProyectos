package com.simps.simps.Dto.Parametrizacion;

public interface ITechniquesDto {
	
	Long getId();

	String getCode();

	String getName();
	
    Boolean getState();
	
	Long getQuantity();
	
}
