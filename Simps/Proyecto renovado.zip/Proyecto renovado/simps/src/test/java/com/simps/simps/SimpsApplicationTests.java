package com.simps.simps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
