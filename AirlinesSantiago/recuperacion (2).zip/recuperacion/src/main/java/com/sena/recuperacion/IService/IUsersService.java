package com.sena.recuperacion.IService;

import com.sena.recuperacion.Entity.Users;

public interface IUsersService extends IBaseService<Users> {

}
