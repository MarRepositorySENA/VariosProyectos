package com.sena.recuperacion.Dto;

public interface ICabinTypeDto extends IGenericDto{
	
	 Long getId();
	 String getName();

}
