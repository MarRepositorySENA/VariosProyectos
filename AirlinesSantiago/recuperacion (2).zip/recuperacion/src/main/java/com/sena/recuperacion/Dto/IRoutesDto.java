package com.sena.recuperacion.Dto;

import java.time.LocalDate;

public interface IRoutesDto extends IGenericDto {
	
    int getOrigenId();
    int getDestinoId();
    LocalDate getFechaInicio();
    LocalDate getFechaFin();

}
