package com.sena.recuperacion.Entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.time.LocalTime;

@Entity
@Table(name = "schedules")
public class Schedules extends ABaseEntity {

    @Column(name = "date", nullable = false)
    private LocalDateTime date;
    
    @Column(name = "time", nullable = false)
    private LocalTime time;

    @ManyToOne
    @JoinColumn(name = "aircraft_id", nullable = false)
    private Aircrafts aircraft;

    @ManyToOne
    @JoinColumn(name = "route_id", nullable = false)
    private Routes route;

    @Column(name = "economy_price", nullable = false)
    private double economyPrice;

    @Column(name = "confirmed", nullable = false)
    private boolean confirmed;
    
    @Column(name = "flight_number", nullable = false)
    private boolean flightNumber;

	public LocalDateTime getDate() {
		return date;
	}

	public void setDate(LocalDateTime date) {
		this.date = date;
	}

	public LocalTime getTime() {
		return time;
	}

	public void setTime(LocalTime time) {
		this.time = time;
	}

	public Aircrafts getAircraft() {
		return aircraft;
	}

	public void setAircraft(Aircrafts aircraft) {
		this.aircraft = aircraft;
	}

	public Routes getRoute() {
		return route;
	}

	public void setRoute(Routes route) {
		this.route = route;
	}

	public double getEconomyPrice() {
		return economyPrice;
	}

	public void setEconomyPrice(double economyPrice) {
		this.economyPrice = economyPrice;
	}

	public boolean isConfirmed() {
		return confirmed;
	}

	public void setConfirmed(boolean confirmed) {
		this.confirmed = confirmed;
	}

	public boolean isFlightNumber() {
		return flightNumber;
	}

	public void setFlightNumber(boolean flightNumber) {
		this.flightNumber = flightNumber;
	}

   
}