package com.sena.recuperacion.Dto;

public interface ICountriesDto extends IGenericDto{

	Long getId();
    String getName();
    
}
