package com.sena.recuperacion.Dto;

public interface IGenericDto {
	
	Long getId();

	String getState();

}
