package com.sena.recuperacion.IService;

import com.sena.recuperacion.Entity.Aircrafts;

public interface IAircraftsService extends IBaseService<Aircrafts>{

}
