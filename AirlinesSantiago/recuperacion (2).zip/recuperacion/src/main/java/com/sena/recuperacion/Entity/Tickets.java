package com.sena.recuperacion.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;

@Entity
@Table(name = "tickets")
public class Tickets extends ABaseEntity {

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users user;

    @ManyToOne
    @JoinColumn(name = "schedule_id", nullable = false)
    private Schedules schedule;

    @ManyToOne
    @JoinColumn(name = "cabin_type_id", nullable = false)
    private CabinTypes cabinType;

    @Column(name = "first_name", length = 50, nullable = false)
    private String firstName;

    @Column(name = "last_name", length = 50, nullable = false)
    private String lastName;
    
    @Column(name = "email", length = 50, nullable = false)
    private String email;

    @Column(name = "phone", length = 15, nullable = false)
    private int phone;

    @Column(name = "passport_number", length = 50, nullable = false)
    private String passportNumber;

    @Column(name = "passport_country_id", length = 50, nullable = false)
    private String passportCountryId;
    
    @Column(name = "passport_photo")
    private String passportPhoto;
    
    @Column(name = "confirmed", nullable = false)
    private boolean confirmed;

	public Users getUser() {
		return user;
	}

	public void setUser(Users user) {
		this.user = user;
	}

	public Schedules getSchedule() {
		return schedule;
	}

	public void setSchedule(Schedules schedule) {
		this.schedule = schedule;
	}

	public CabinTypes getCabinType() {
		return cabinType;
	}

	public void setCabinType(CabinTypes cabinType) {
		this.cabinType = cabinType;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getPhone() {
		return phone;
	}

	public void setPhone(int phone) {
		this.phone = phone;
	}

	public String getPassportNumber() {
		return passportNumber;
	}

	public void setPassportNumber(String passportNumber) {
		this.passportNumber = passportNumber;
	}

	public String getPassportCountryId() {
		return passportCountryId;
	}

	public void setPassportCountryId(String passportCountryId) {
		this.passportCountryId = passportCountryId;
	}

	public String getPassportPhoto() {
		return passportPhoto;
	}

	public void setPassportPhoto(String passportPhoto) {
		this.passportPhoto = passportPhoto;
	}

	public boolean isConfirmed() {
		return confirmed;
	}

	public void setConfirmed(boolean confirmed) {
		this.confirmed = confirmed;
	}

    
}