package com.sena.recuperacion.Controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sena.recuperacion.Dto.IRoutesDto;
import com.sena.recuperacion.Entity.Routes;
import com.sena.recuperacion.IService.IRoutesService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("v1/api/routes")
public class RoutesController extends ABaseController<Routes, IRoutesService> {

    protected RoutesController(IRoutesService service) {
        super(service, "Routes");
    }
    
    @PostMapping("/findByOrigenAndDestino")
    public ResponseEntity<List<Routes>> obtenRoutes(@RequestBody IRoutesDto routesDto){
        try {
            return ResponseEntity.ok(service.findByOrigenAndDestino(routesDto.getOrigenId(),
            routesDto.getDestinoId(), routesDto.getFechaInicio(), routesDto.getFechaFin()));
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }
}