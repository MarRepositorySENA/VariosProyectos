package com.sena.recuperacion.IService;

import com.sena.recuperacion.Entity.CabinTypes;

public interface ICabinTypesService extends IBaseService<CabinTypes>{

}
