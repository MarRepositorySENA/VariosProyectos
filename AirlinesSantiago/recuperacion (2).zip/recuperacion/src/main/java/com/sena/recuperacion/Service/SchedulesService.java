package com.sena.recuperacion.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sena.recuperacion.Entity.CabinTypes;
import com.sena.recuperacion.Entity.Schedules;
import com.sena.recuperacion.IRepository.CabinTypesRepository;
import com.sena.recuperacion.IRepository.IBaseRepository;
import com.sena.recuperacion.IRepository.SchedulesRepository;
import com.sena.recuperacion.IService.ISchedulesService;

@Service
public class SchedulesService extends ABaseService<Schedules> implements ISchedulesService {

	@Autowired
    private SchedulesRepository repository;

    @Autowired
    private CabinTypesRepository cabinTypesRepository;

    @Override
    protected IBaseRepository<Schedules, Long> getRepository() {
        return repository;
    }



}