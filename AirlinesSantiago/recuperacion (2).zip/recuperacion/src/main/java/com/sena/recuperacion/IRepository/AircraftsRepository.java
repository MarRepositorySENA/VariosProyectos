package com.sena.recuperacion.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.recuperacion.Entity.Aircrafts;

@Repository
public interface AircraftsRepository extends IBaseRepository<Aircrafts, Long> {

}