package com.sena.recuperacion.Dto;

public interface IOfficesDto extends IGenericDto{

	Long getId();
    Long getCountryId();
    String getTitle();
    String getPhone();
    String getContact();

}
