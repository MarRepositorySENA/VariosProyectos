package com.sena.recuperacion.IRepository;

import org.springframework.stereotype.Repository;

import com.sena.recuperacion.Entity.CabinTypes;

@Repository
public interface CabinTypesRepository extends IBaseRepository<CabinTypes, Long> {
	
}