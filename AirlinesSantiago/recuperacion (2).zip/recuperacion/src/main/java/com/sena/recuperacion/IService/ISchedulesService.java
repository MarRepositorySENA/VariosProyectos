package com.sena.recuperacion.IService;


import com.sena.recuperacion.Entity.Schedules;

public interface ISchedulesService extends IBaseService<Schedules> {
	
	    
	   
	}