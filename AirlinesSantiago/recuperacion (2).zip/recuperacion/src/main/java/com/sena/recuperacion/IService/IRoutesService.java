package com.sena.recuperacion.IService;

import java.time.LocalDate;
import java.util.List;

import com.sena.recuperacion.Entity.Routes;

public interface IRoutesService extends IBaseService<Routes>{
	
	 List<Routes> findByOrigenAndDestino(Integer origen, Integer destino, LocalDate fechaInicio, LocalDate fechaFin);

}
