package com.sena.recuperacion.IService;

import com.sena.recuperacion.Entity.Roles;

public interface IRolesService extends IBaseService<Roles> {

}
