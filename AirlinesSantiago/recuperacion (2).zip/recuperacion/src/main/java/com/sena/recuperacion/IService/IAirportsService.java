package com.sena.recuperacion.IService;

import com.sena.recuperacion.Entity.Airports;

public interface IAirportsService extends IBaseService<Airports> {

}
