package com.sena.recuperacion.Dto;

public interface IRolesDto extends IGenericDto {
	
	Long getId();
    String getTitle();

}
