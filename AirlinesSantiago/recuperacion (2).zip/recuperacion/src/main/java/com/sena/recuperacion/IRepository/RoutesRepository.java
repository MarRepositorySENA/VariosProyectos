package com.sena.recuperacion.IRepository;

import java.time.LocalDate;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.sena.recuperacion.Dto.IRoutesDto;
import com.sena.recuperacion.Entity.Routes;

@Repository
public interface RoutesRepository extends IBaseRepository<Routes, Long> {
	
	 @Query(value = 
			 "SELECT r.* " +
			 "FROM Routes ASr " +
	         "WHERE (:origen IS NULL OR r.departureAirport.id = :origen) " +
	         "AND (:destino IS NULL OR r.arrivalAirport.id = :destino) " +
	         "AND (:fechaInicio IS NULL OR r.schedule.date >= :fechaInicio) " +
	         "AND (:fechaFin IS NULL OR r.schedule.date <= :fechaFin)", nativeQuery = true)
	    List<Routes> findByOrigenAndDestino(
	            @Param("origen") Integer origen, @Param("destino") Integer destino,
	            @Param("fechaInicio") LocalDate fechaInicio, @Param("fechaFin") LocalDate fechaFin);
	
   
}