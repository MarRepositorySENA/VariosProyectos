package com.sena.recuperacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecuperacionApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecuperacionApplication.class, args);
	}

}
