package com.sena.recuperacion.IService;

import com.sena.recuperacion.Entity.Offices;

public interface IOfficesService extends IBaseService<Offices> {

}
