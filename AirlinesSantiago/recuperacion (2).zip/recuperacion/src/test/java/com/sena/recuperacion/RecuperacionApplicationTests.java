package com.sena.recuperacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecuperacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
