$('#exitButton').click(function() {
    window.location.href = '../view/navbar.html';  // Reemplaza con la ruta a tu navbar
  });

$(document).ready(function () {
     
    var spanishTranslation = {
        "sEmptyTable":     "No hay datos disponibles en la tabla",
        "sInfo":           "Mostrando START a END de TOTAL entradas",
        "sInfoEmpty":      "Mostrando 0 a 0 de 0 entradas",
        "sInfoFiltered":   "(filtrado de MAX entradas totales)",
        "sInfoPostFix":    "",
        "sInfoThousands":  ",",
        "sLengthMenu":     "Mostrar MENU entradas",
        "sLoadingRecords": "Cargando...",
        "sProcessing":     "Procesando...",
        "sSearch":         "Buscar:",
        "sZeroRecords":    "No se encontraron coincidencias",
        "oPaginate": {
            "sFirst":    "Primero",
            "sLast":     "Último",
            "sNext":     "Siguiente",
            "sPrevious": "Anterior"
        },
        "oAria": {
            "sSortAscending":  ": Activar para ordenar la columna ascendente",
            "sSortDescending": ": Activar para ordenar la columna descendente"
        }
    };

    // Inicialización de DataTables con la traducción en español
    var table1 = $('#table1').DataTable({
        "language": spanishTranslation
    });

    var table2 = $('#table2').DataTable({
        "language": spanishTranslation
    });

    
    loadData();
    loadAirportsData();
    clearFilters();

    // Manejar cambios en los radios de tipo de viaje
    $('input[name="trip-type"]').change(function () {
        if ($(this).val() === "one-way") {
            filterRoutes();
        } else {
            filterRoutes2();
        }
    });

    // Función para cargar datos de vuelos de salida
    function loadData() {
        console.log("Ejecutando loadData");
        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/routes",
            method: "GET",
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                updateTable(table1, response.data);
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }

    // Función de aeropuertos para autocompletar
    function loadAirportsData() {
        console.log("Ejecutando loadAirportsData");
        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/airports",
            method: "GET",
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                var airports = response.data.map(function (airport) {
                    return {
                        label: airport.name,
                        value: airport.id
                    };
                });

                $("#origin, #destination").autocomplete({
                    source: airports,
                    select: function (event, ui) {
                        $(this).val(ui.item.label);
                        $(this).siblings('input[type="hidden"]').val(ui.item.value);
                        applyFilters(); // Aplicar filtros al seleccionar aeropuerto
                        return false;
                    }
                });
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }

    // Función para aplicar filtros y actualizar la tabla de vuelos de salida
    function applyFilters() {
        var tripType = $('input[name="trip-type"]:checked').val();
        if (tripType === "one-way") {
            filterRoutes();
        } else {
            filterRoutes2();
        }
    }

    // Función para filtrar de vuelos de salida
    function filterRoutes() {
        var origenId = parseInt($('#originId').val());
        var destinoId = parseInt($('#destinationId').val());
        var fechaInicio = $('#departure-date').val();
        var fechaFin = $('#return-date').val();

        var requestData = {
            origenId: origenId,
            destinoId: destinoId,
            fechaInicio: fechaInicio,
            fechaFin: fechaFin
        };

        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/routes/consul",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(requestData),
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                updateTable(table1, response.data);
                $("#resultData").show();
                $("#resultDataReturn").hide();
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }

    // Función para filtrar de vuelos de retorno
    function filterRoutes2() {
        var origenId = parseInt($('#originId').val());
        var destinoId = parseInt($('#destinationId').val());
        var fechaInicio = $('#departure-date').val();
        var fechaFin = $('#return-date').val();

        var requestData = {
            origenId: destinoId,
            destinoId: origenId,
            fechaInicio: fechaFin,
            fechaFin: fechaInicio
        };

        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/routes/consulReturn",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(requestData),
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                updateTable(table2, response.data);
                $("#resultData").hide();
                $("#resultDataReturn").show();
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }

    // Función para actualizar una tabla de DataTable
    function updateTable(table, data) {
        table.clear().draw();
        data.forEach(function (item) {
            if (!item.deletedAt) {
                table.row.add([
                    item.createdAt,
                    item.distance,
                    item.flightTime,
                    item.departureAirport.name,
                    item.destinationAirport.name
                ]).draw(false);
            }
        });
    }

    // Función para limpiar los filtros y restaurar la tabla
    function clearFilters() {
        $('#origin, #destination').val('');
        $('#originId, #destinationId').val('');
        $('#departure-date, #return-date').val('');
        $('input[name="trip-type"][value="one-way"]').prop('checked', true);
        applyFilters(); // Aplicar filtros al limpiar
    }
});