$('#exitButton').click(function() {
    window.location.href = '../view/navbar.html';  
}) 

  $('#reservar').click(function() {
    window.location.href = '../view/confirmacionreserva.html'; 
  });


$(document).ready(function () {
     
    var spanishTranslation = {
        "sEmptyTable":     "No hay datos disponibles en la tabla",
        "sInfo":           "Total entradas",
        "sInfoEmpty":      "",
        "sInfoFiltered":   "",
        "sInfoPostFix":    "",
        "sInfoThousands":  ",",
        "sLengthMenu":     "Vuelos Disponibles",
        "sLoadingRecords": "Cargando...",
        "sProcessing":     "Procesando...",
        "sSearch":         "Buscar:",
        "sZeroRecords":    "No se encontraron vuelos",
        "oPaginate": {
            "sFirst":    "Primero",
            "sLast":     "Último",
            "sNext":     "Siguiente",
            "sPrevious": "Anterior"
        },
        "oAria": {
            "sSortAscending":  ": Activar para ordenar la columna ascendente",
            "sSortDescending": ": Activar para ordenar la columna descendente"
        }
    };

    
    var table1 = $('#routesTable').DataTable({
        "language": spanishTranslation
    });

    var table2 = $('#routesTable2').DataTable({
        "language": spanishTranslation
    });

    
    loadData();
    loadAirportsData();
    clearFilters();


    $('input[name="trip-type"]').change(function () {
        if ($(this).val() === "one-way") {
            filterRoutes();
        } else {
            filterRoutes2();
        }
    });

    
    function loadData() {
        console.log("Ejecutando loadData");
        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/routes",
            method: "GET",
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                updateTable(table1, response.data);
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }


    function loadAirportsData() {
        console.log("Ejecutando loadAirportsData");
        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/airports",
            method: "GET",
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                var airports = response.data.map(function (airport) {
                    return {
                        label: airport.name,
                        value: airport.id
                    };
                });

                $("#origin, #destination").autocomplete({
                    source: airports,
                    select: function (event, ui) {
                        $(this).val(ui.item.label);
                        $(this).siblings('input[type="hidden"]').val(ui.item.value);
                        applyFilters(); // Aplicar filtros al seleccionar aeropuerto
                        return false;
                    }
                });
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }

   
    function applyFilters() {
        var tripType = $('input[name="trip-type"]:checked').val();
        if (tripType === "one-way") {
            filterRoutes();
        } else {
            filterRoutes2();
        }
    }

   
    function filterRoutes() {
        var origenId = parseInt($('#originId').val());
        var destinoId = parseInt($('#destinationId').val());
        var fechaInicio = $('#departure-date').val();
        var fechaFin = $('#return-date').val();

        var requestData = {
            origenId: origenId,
            destinoId: destinoId,
            fechaInicio: fechaInicio,
            fechaFin: fechaFin
        };

        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/routes/consul",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(requestData),
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                updateTable(table1, response.data);
                $("#resultData").show();
                $("#resultData2").hide();
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }

   
    function filterRoutes2() {
        var origenId = parseInt($('#originId').val());
        var destinoId = parseInt($('#destinationId').val());
        var fechaInicio = $('#departure-date').val();
        var fechaFin = $('#return-date').val();

        var requestData = {
            origenId: destinoId,
            destinoId: origenId,
            fechaInicio: fechaFin,
            fechaFin: fechaInicio
        };

        $.ajax({
            url: "http://localhost:9000/recuperacion/v1/api/routes/consul2",
            method: "POST",
            contentType: "application/json",
            data: JSON.stringify(requestData),
            dataType: "json",
            success: function (response) {
                console.log(response.data);
                updateTable(table2, response.data);
                $("#resultData").hide();
                $("#resultData2").show();
            },
            error: function (error) {
                console.error("Error en la solicitud:", error);
            }
        });
    }

    // Función para actualizar una tabla de DataTable
    function updateTable(table, data) {
        table.clear().draw();
        data.forEach(function (item) {
            if (!item.deletedAt) {
                table.row.add([
                    item.createdAt,
                    item.distance,
                    item.flightTime,
                    item.departureAirport.name,
                    item.destinationAirport.name
                ]).draw(false);
            }
        });
    }

    // Función para limpiar los filtros y restaurar la tabla
    $('#clearButton').click(function() {
        clearFilters();
    });
    
    function clearFilters() {
        $('#origin, #destination').val('');
        $('#originId, #destinationId').val('');
        $('#departure-date, #return-date').val('');
        $('input[name="trip-type"][value="one-way"]').prop('checked', true);
        
        // Limpiar las tablas DataTable
        table1.clear().draw();
        table2.clear().draw();
        
        applyFilters(); // Aplicar filtros al limpiar
    }
})  