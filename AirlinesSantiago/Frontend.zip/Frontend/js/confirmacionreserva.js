$(document).ready(function() {
    $('#salir').click(function() {
        Swal.fire({
            title: '¿Estás seguro de que deseas salir?',
            text: 'Los cambios no se guardarán.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sí, salir',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = '../view/busquedavuelos.html';
            }
        });
    });

    $('#reservar-vuelo').click(function() {
        Swal.fire({
            title: 'Vuelo Reservado con Éxito',
            text: 'Tu vuelo ha sido reservado correctamente.',
            icon: 'success',
            confirmButtonText: 'Aceptar'
        }).then(() => {
            window.location.href = '../view/confirmacionfactura.html';
        });
    });
});
$(document).ready(function() {
    // Cargar los datos de la búsqueda de vuelos desde el almacenamiento local
    const vueloSalida = JSON.parse(localStorage.getItem('vueloSalida'));
    const vueloRegreso = JSON.parse(localStorage.getItem('vueloRegreso'));

    // Mostrar los detalles del vuelo de salida
    if (vueloSalida) {
        $('#vuelo-salida').html(`
            <tr>
                <td>Origen: ${vueloSalida.origen}</td>
                <td>Destino: ${vueloSalida.destino}</td>
                <td>Tipo de cabina: ${vueloSalida.tipoCabina}</td>
                <td>Fecha: ${vueloSalida.fecha}</td>
                <td>Número de vuelo: ${vueloSalida.numeroVuelo}</td>
            </tr>
        `);
    }

    // Mostrar los detalles del vuelo de regreso
    if (vueloRegreso) {
        $('#vuelo-regreso').html(`
            <tr>
                <td>Origen: ${vueloRegreso.origen}</td>
                <td>Destino: ${vueloRegreso.destino}</td>
                <td>Tipo de cabina: ${vueloRegreso.tipoCabina}</td>
                <td>Fecha: ${vueloRegreso.fecha}</td>
                <td>Número de vuelo: ${vueloRegreso.numeroVuelo}</td>
            </tr>
        `);
    }

    // Cargar datos de países y configurar autocompletado con Select2
    let paises = [];
    $.get('https://restcountries.com/v3.1/all', function(data) {
        paises = data.map(country => ({
            id: country.name.common,
            text: `${country.flag} ${country.name.common}`
        }));
        $('#pais-pasaporte').select2({
            data: paises,
            placeholder: 'Seleccionar país',
            allowClear: true
        });
    });

    // Agregar un nuevo pasajero
    $('#agregar-pasajero').on('click', function() {
        const nombres = $('#nombres').val();
        const apellidos = $('#apellidos').val();
        const fechaNacimiento = $('#fecha-nacimiento').val();
        const numeroPasaporte = $('#numero-pasaporte').val();
        const paisPasaporte = $('#pais-pasaporte').val();
        const telefono = $('#telefono').val();
        const fotoPasaporte = $('#foto-pasaporte')[0].files[0];

        if (nombres && apellidos && fechaNacimiento && numeroPasaporte && paisPasaporte && telefono && fotoPasaporte) {
            const reader = new FileReader();
            reader.onload = function(e) {
                const fotoPasaporteData = e.target.result;
                $('#lista-pasajeros tbody').append(`
                    <tr>
                        <td>${nombres}</td>
                        <td>${apellidos}</td>
                        <td>${fechaNacimiento}</td>
                        <td>${numeroPasaporte}</td>
                        <td>${paisPasaporte}</td>
                        <td>${telefono}</td>
                        <td><button type="button" class="btn btn-secondary ver-pasaporte" data-foto="${fotoPasaporteData}">Ver pasaporte</button></td>
                        <td><button type="button" class="btn btn-danger eliminar-pasajero">Eliminar</button></td>
                    </tr>
                `);
            };
            reader.readAsDataURL(fotoPasaporte);
        } else {
            Swal.fire('Error', 'Por favor complete todos los campos.', 'error');
        }
    });

    // Ver la foto del pasaporte
    $(document).on('click', '.ver-pasaporte', function() {
        const foto = $(this).data('foto');
        Swal.fire({
            title: 'Foto del Pasaporte',
            imageUrl: foto,
            imageAlt: 'Foto del Pasaporte'
        });
    });

    // Eliminar un pasajero
    $(document).on('click', '.eliminar-pasajero', function() {
        $(this).closest('tr').remove();
    });

    // Reservar vuelo
    $('#reservar-vuelo').on('click', function() {
        // Aquí puedes agregar la lógica para reservar el vuelo
        Swal.fire('Reserva', 'El vuelo ha sido reservado con éxito.', 'success');
    });

});
